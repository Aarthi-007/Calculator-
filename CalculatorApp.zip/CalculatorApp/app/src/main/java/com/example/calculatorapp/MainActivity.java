package com.example.calculatorapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView result;

    private String currentInput = "";
    private double firstNumber = 0;
    private String operator = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result = findViewById(R.id.result);

        Button btn0 = findViewById(R.id.btn0);
        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn4 = findViewById(R.id.btn4);
        Button btn5 = findViewById(R.id.btn5);
        Button btn6 = findViewById(R.id.btn6);
        Button btn7 = findViewById(R.id.btn7);
        Button btn8 = findViewById(R.id.btn8);
        Button btn9 = findViewById(R.id.btn9);

        Button addBtn = findViewById(R.id.addBtn);
        Button subBtn = findViewById(R.id.subBtn);
        Button mulBtn = findViewById(R.id.mulBtn);
        Button divideBtn = findViewById(R.id.divideBtn);

        Button equalBtn = findViewById(R.id.equalBtn);
        Button clearBtn = findViewById(R.id.clearBtn);
        Button dotBtn = findViewById(R.id.dotBtn);
        Button backBtn = findViewById(R.id.backBtn);

        btn0.setOnClickListener(v -> appendNumber("0"));
        btn1.setOnClickListener(v -> appendNumber("1"));
        btn2.setOnClickListener(v -> appendNumber("2"));
        btn3.setOnClickListener(v -> appendNumber("3"));
        btn4.setOnClickListener(v -> appendNumber("4"));
        btn5.setOnClickListener(v -> appendNumber("5"));
        btn6.setOnClickListener(v -> appendNumber("6"));
        btn7.setOnClickListener(v -> appendNumber("7"));
        btn8.setOnClickListener(v -> appendNumber("8"));
        btn9.setOnClickListener(v -> appendNumber("9"));

        dotBtn.setOnClickListener(v -> {
            if (!currentInput.contains(".")) {
                if (currentInput.isEmpty()) {
                    currentInput = "0.";
                } else {
                    currentInput += ".";
                }
                result.setText(currentInput);
            }
        });

        addBtn.setOnClickListener(v -> setOperator("+"));
        subBtn.setOnClickListener(v -> setOperator("-"));
        mulBtn.setOnClickListener(v -> setOperator("*"));
        divideBtn.setOnClickListener(v -> setOperator("/"));

        equalBtn.setOnClickListener(v -> calculateResult());

        clearBtn.setOnClickListener(v -> {
            currentInput = "";
            firstNumber = 0;
            operator = "";
            result.setText("0");
        });

        backBtn.setOnClickListener(v -> {
            if (!currentInput.isEmpty()) {
                currentInput =
                        currentInput.substring(0, currentInput.length() - 1);

                if (currentInput.isEmpty()) {
                    result.setText("0");
                } else {
                    result.setText(currentInput);
                }
            }
        });
    }

    private void appendNumber(String number) {
        currentInput += number;
        result.setText(currentInput);
    }

    private void setOperator(String op) {
        if (!currentInput.isEmpty()) {
            firstNumber = Double.parseDouble(currentInput);
            operator = op;
            currentInput = "";
        }
    }

    private void calculateResult() {

        if (currentInput.isEmpty()) {
            return;
        }

        double secondNumber = Double.parseDouble(currentInput);
        double answer = 0;

        switch (operator) {

            case "+":
                answer = firstNumber + secondNumber;
                break;

            case "-":
                answer = firstNumber - secondNumber;
                break;

            case "*":
                answer = firstNumber * secondNumber;
                break;

            case "/":

                if (secondNumber == 0) {
                    result.setText("Error");
                    return;
                }

                answer = firstNumber / secondNumber;
                break;
        }

        if (answer == (long) answer) {
            result.setText(String.valueOf((long) answer));
        } else {
            result.setText(String.valueOf(answer));
        }

        currentInput = String.valueOf(answer);
        operator = "";
    }
}